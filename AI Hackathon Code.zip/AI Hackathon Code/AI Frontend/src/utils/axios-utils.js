import axios from 'axios'
const client=axios.create({baseURL:"http://localhost:8302"})
// client.interceptor.request.use((request)=>{
    // return request
// })
    // client.defaults.headers.common.Authorization=`Bearer token ${token || ""}`
   

export default client