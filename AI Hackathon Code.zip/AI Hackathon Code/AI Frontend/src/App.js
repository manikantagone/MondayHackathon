
import React, { useEffect, useState } from 'react';
import { useFormik } from 'formik';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { Divider } from 'primereact/divider';
import { classNames } from 'primereact/utils';
import mond from "./Monday.png"
import { Toast } from 'primereact/toast';
import { useRef } from 'react';
// import { CountryService } from '../service/CountryService';
import './App.css'

export const App = () => {
    const toast = useRef(null);
    const [countries, setCountries] = useState([]);
    const [showMessage, setShowMessage] = useState(false);
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({});
    // const countryservice = new CountryService();

    useEffect(() => {
        
        // countryservice.getCountries().then(data => setCountries(data));
    }, []); // eslint-disable-line react-hooks/exhaustive-deps

    const formik = useFormik({
        initialValues: {
            context: '',
            email: ''
        },
        validate: (data) => {
            let errors = {};

            if (!data.email) {
                errors.email = 'Email is required.';
            }
            else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
                errors.email = 'Invalid email address. E.g. example@email.com';
            }
            return errors;
        },
        onSubmit: (data) => {
            setLoading(true)
            setFormData(data);
            setShowMessage(true);
console.log("formdata",data)
fetch("http://localhost:8302/AIcall",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)})
.then(res=>{
    // alert(res)
    setLoading(false)
    toast.current.show({severity: 'success', summary: 'Success Message', detail: 'Email Sent Successfully'})
formik.resetForm()}  )   
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };

    const dialogFooter = <div className="flex justify-content-center"><Button label="OK" className="p-button-text" autoFocus onClick={() => setShowMessage(false)} /></div>;
    const passwordHeader = <h6>Pick a password</h6>;
    const passwordFooter = (
        <React.Fragment>
            <Divider />
            <p className="mt-2">Suggestions</p>
            <ul className="pl-2 ml-2 mt-0" style={{ lineHeight: '1.5' }}>
                <li>At least one lowercase</li>
                <li>At least one uppercase</li>
                <li>At least one numeric</li>
                <li>Minimum 8 characters</li>
            </ul>
        </React.Fragment>
    );

    return (
        <div className="form-demo">
          <img src={mond} />
          <Toast ref={toast} />

            <div className="flex justify-content-center formy">
                <div className="card">
                    <h3 className="text-center">Details required to send mail</h3>
                    <form onSubmit={formik.handleSubmit} className="p-fluid">
                        <div className="field">
                            <span className="p-float-label">
                                <InputText id="context" name="context" value={formik.values.context} onChange={formik.handleChange} autoFocus className={classNames({ 'p-invalid': isFormFieldValid('context') })} />
                                <label htmlFor="context" className={classNames({ 'p-error': isFormFieldValid('context') })}>What is the Email about?*</label>
                            </span>
                            {getFormErrorMessage('name')}
                        </div>
                        <div className="field">
                            <span className="p-float-label p-input-icon-right">
                                <i className="pi pi-envelope" />
                                <InputText id="email" name="email" value={formik.values.email} onChange={formik.handleChange} className={classNames({ 'p-invalid': isFormFieldValid('email') })} />
                                <label htmlFor="email" className={classNames({ 'p-error': isFormFieldValid('email') })}>Reciever's Email*</label>
                            </span>
                            {getFormErrorMessage('email')}
                        </div>
                    
                        {/* <div className="field">
                            <span className="p-float-label">
                                <Dropdown id="country" name="country" value={formik.values.country} onChange={formik.handleChange} options={countries} optionLabel="name" />
                                <label htmlFor="country">Saved Email template</label>
                            </span>
                        </div> */}

                        <Button type="submit" label="Submit" disabled={loading} className="mt-2" />
                    </form>
                </div>
            </div>
        </div>
    );
}
export default App