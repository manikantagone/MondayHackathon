const initMondayClient = require('monday-sdk-js');
const createItem = async (token, boardId, item_name,column_values) => {
  try {
    const mondayClient = initMondayClient({ token });

    const query = `mutation create_item($boardId: Int!, $item_name: String!,$column_values:JSON!) {
        create_item(board_id: $boardId,  item_name:$item_name,column_values:$column_values) {
          id
        }
      }
      `;
    const variables = { boardId,item_name,column_values };

    const response = await mondayClient.api(query, { variables });
    return response;
  } catch (err) {
    console.error(err);
  }
};
// const getColumnValue = async (token, itemId) => {
//   try {
//     const mondayClient = initMondayClient();
//     mondayClient.setToken(token);

//     const query = `query($itemId: [Int] {items (ids: $itemId) {column_values{name}}}`;
//     const variables = {  itemId };

//     const response = await mondayClient.api(query, { variables });
//     console.log(response,"resp")
//     return response.data.items[0].column_values[0].value;
//   } catch (err) {
//     console.error(err);
//   }
// };
const getColumnValue = async (token, itemId, columnId) => {
  try {
    const mondayClient = initMondayClient();
    mondayClient.setToken(token);

    const query = `query($itemId: [Int], $columnId: [String]) {
        items (ids: $itemId) {
          column_values(ids:$columnId) {
            value
          }
        }
      }`;
    const variables = { columnId, itemId };

    const response = await mondayClient.api(query, { variables });
    return response.data.items[0].column_values[0].value;
  } catch (err) {
    console.error(err);
  }
};
const changeColumnValue = async (token, boardId, itemId, columnId, value) => {
  try {
    const mondayClient = initMondayClient({ token });

    const query = `mutation change_column_value($boardId: Int!, $itemId: Int!, $columnId: String!, $value: JSON!) {
        change_column_value(board_id: $boardId, item_id: $itemId, column_id: $columnId, value: $value) {
          id
        }
      }
      `;
    const variables = { boardId, columnId, itemId, value };

    const response = await mondayClient.api(query, { variables });
    return response;
  } catch (err) {
    console.error(err);
  }
};
const change_simple_column_value = async (
  token,
  boardId,
  itemId,
  columnId,
  value
) => {
  try {
    const mondayClient = initMondayClient({ token });

    const query = `mutation change_simple_column_value($boardId: Int!, $itemId: Int!, $columnId: String!, $value: String!) {
      change_simple_column_value(board_id: $boardId, item_id: $itemId, column_id: $columnId, value: $value) {
          id
        }
      }
      `;
    const variables = { boardId, columnId, itemId, value };

    const response = await mondayClient.api(query, { variables });
    return response;
  } catch (err) {
    console.error(err);
  }
};
module.exports = {
  getColumnValue,
  createItem,
  changeColumnValue,
  change_simple_column_value
};
