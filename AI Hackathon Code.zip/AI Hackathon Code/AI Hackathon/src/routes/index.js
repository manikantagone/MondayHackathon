const router = require('express').Router();
const MailController=require('../controllers/MailController')


router.post('/AIcall',MailController.AIcall)

module.exports = router;
