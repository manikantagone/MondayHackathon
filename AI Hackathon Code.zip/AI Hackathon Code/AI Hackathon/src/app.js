require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const routes = require('./routes');
const cors = require('cors')
const { PORT: port } = process.env;
const app = express();

app.use(express.json());
app.get("/",(req,res)=>{
  res.send("sss")
})
app.use(cors())
app.use(routes);
app.listen(8302, () => {
  console.log("running at ",8302)
});

module.exports = app;
