
const Imap = require('imap');
const { simpleParser } = require('mailparser');

async function AIcall(req, res) {
  console.log(req.body)
  let data = (req.body)
  let mail = data.email
  let query = data.context
  var nodemailer = require('nodemailer');
  const axios = require("axios");
  let apicall = JSON.stringify({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "user",
        content: `${query}`,
      },
    ],
    temperature: 1,
    top_p: 1,
    n: 1,
    stream: false,
    max_tokens: 250,
    presence_penalty: 0,
    frequency_penalty: 0,
  });

  let config = {
    method: "post",
    maxBodyLength: Infinity,
    url: "https://api.openai.com/v1/chat/completions",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization:
        process.env.AIkey,
    },
    data: apicall,
  };
  axios
    .request(config)
    .then(async (response) => {
      let responseData = 
        response.data.choices[0].message.content
     
      var cleanedResponse = responseData.replace(/(\n\s*){2,}/g, " ");
      cleanedResponse = cleanedResponse.replace(/\n/g, " ");
      console.log("cleanedResponse",cleanedResponse)
      // 
        var transporter = nodemailer.createTransport({
          service: 'outlook',
          auth: {
            user: process.env.user,
            pass: process.env.pass,
          },
        });
        var mailOptions = {
          from: process.env.user,
          to: mail,
          subject: 'Auto Generated Mail',
          text: cleanedResponse,
        };
        transporter.sendMail(mailOptions, function (error, info) {
          if (error) {
            console.log(error);
          } else {
            console.log(info, 'your  email message has been sent succesfully');
            res.status(200).send('Mail Sent');
          }
        });
    })
    .catch((error) => {
      console.log(error);
    });
 
}

module.exports = { AIcall };
